package Back.AST.ExpressionStatement;

import Back.AST.SimpleStatementNode;

public abstract class ExpressionNode extends SimpleStatementNode {
    public ExpressionNode(int line, String name) {
        super(line, name);
    }

    @Override
    public void printTree(int indent) {
        super.printTree(indent);
    }
}
